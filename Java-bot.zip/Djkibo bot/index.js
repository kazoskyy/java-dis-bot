const discord = require("discord.js");
const config = require("./botData/config.json");
const { readdirSync } = require("fs");
const { sep } = require("path");
const fs = require("fs");

const client = new discord.Client();
client.commands = new discord.Collection();
client.info = []

//Giveaway systeem
const { GiveawaysManager } = require('discord-giveaways');

client.giveawaysManager = new GiveawaysManager(client, {
    storage: "./botData/giveaways.json",
    updateCountdownEvery: 5000,
    default: {
        botsCanWin: false,
        exemptPermissions: [],
        embedColor: config.color,
        embedColorEnd: config.color,
        reaction: "🎉"
    }
});

module.exports = client

//Command Handler
const dir = "./commands"

readdirSync(dir).forEach(dirs => {
    const commands = readdirSync(`${dir}${sep}${dirs}${sep}`).filter(files => files.endsWith(".js"));
    for (const file of commands) {
        const pull = require(`${dir}/${dirs}/${file}`);
        client.commands.set(pull.help.name, pull);
        if(pull.help.alias){
            pull.help.alias.forEach(a => {
            client.commands.set(a, pull)
            })
        }
        if(!client.info.includes(pull.help)){
            client.info.push(pull.help)
        }
        console.log(`[INFO] ${pull.help.name} is geladen | ${dirs}`)
    }
})

//Bot opstarten
client.on("ready", async () => {

    console.log(`[INFO] ${client.user.username} is geladen!`);
    client.user.setActivity(config.status, {type: "WATCHING"});
    
});

//Berichten systeem & command systeem
client.on("message", async message => {

    if (message.author.bot) return;

    if (message.channel.type === "dm") return;

    var prefix = config.prefix;

    var msg = message.content.toLowerCase();

    var messageArray = message.content.split(" ");

    var command = messageArray[0];

    var arguments = messageArray.slice(1);

    if (!message.content.startsWith(prefix)) return;

    var commands = client.commands.get(command.slice(prefix.length));

    if (commands) commands.run(client, message, arguments);

    if (message.content.startsWith("help")) {
        message.channel.send(`De prefix van deze server is: \`${config.prefix}\``)
    }

});

client.login(config.token);
