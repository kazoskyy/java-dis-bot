const discord = require('discord.js');
const config = require("../../botData/config.json");

module.exports.run = (client, message, args) => {

        const noUserGiven = new discord.MessageEmbed()
        .setColor(config.color)
        .addField("**:x: Error:**", `Gebruik het zo: \`${config.prefix}kick <gebruiker> [reden]\``)
        .setFooter(config.footer, client.user.displayAvatarURL())


        const noUserFound = new discord.MessageEmbed()
        .setColor(config.color)
        .addField("**:x: Error:**", "De opgegeven gebruiker kan niet worden gevonden!")
        .setFooter(config.footer, client.user.displayAvatarURL())

        const noPerms = new discord.MessageEmbed()
        .setColor(config.color)
        .addField("**:x: Error:**", "Deze gebruiker kan niet worden gekicked!")
        .setFooter(config.footer, client.user.displayAvatarURL())


        const geenpermissies = new discord.MessageEmbed()
        .setColor(config.color)
        .addField("**:x: Error:**", "Je hebt hier geen permissies voor!")
        .setFooter(config.footer, client.user.displayAvatarURL())
        if(!message.member.permissions.has("KICK_MEMBERS")) return message.channel.send(geenpermissies)

        const ikgeenpermissies = new discord.MessageEmbed()
        .setColor(config.color)
        .addField("**:x: Error:**", "Ik heb hier geen permissies voor!")
        .setFooter(config.footer, client.user.displayAvatarURL())
        if(!message.guild.me.permissions.has("KICK_MEMBERS")) return message.channel.send(ikgeenpermissies)

        const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

        if(!args[0]) return message.channel.send(noUserGiven);

        if(!member) return message.channel.send(noUserFound);

        if (member.hasPermission("KICK_MEMBERS")) return message.channel.send(noPerms);

        var reason = args.slice(1).join(" ");

        if(!reason) reason = 'Geen reden opgegeven.';

        try{     
        member.kick(`${reason}`)
              
        const kickMessage = new discord.MessageEmbed()
        .setTitle('Gebruiker gekicked!')
        .setThumbnail(member.user.displayAvatarURL())
        .addField('Gebruiker:', member)
        .addField('Moderator:', message.author)
        .addField('Reden:', reason)
        .setFooter(config.footer, client.user.displayAvatarURL())
        .setColor(config.color)

        message.channel.send(kickMessage);
        } catch (e) {
                message.channel.send(':x: Er is iets misgegaan.')
                console.log(e)
        }
}

module.exports.help = {
name: "kick",
cat: "mod",
desc: "Hiermee kan je iemand kicken"
}