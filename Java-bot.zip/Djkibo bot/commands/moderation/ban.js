const discord = require('discord.js');
const config = require("../../botData/config.json");

module.exports.run = (client, message, args) => {

        const noUserGiven = new discord.MessageEmbed()
        .setColor(config.color)
        .addField("**:x: Error:**", `Gebruik het zo: \`${config.prefix}ban <gebruiker> [reden]\``)
        .setFooter(config.footer, client.user.displayAvatarURL())

        const noUserFound = new discord.MessageEmbed()
        .setColor(config.color)
        .addField("**:x: Error:**", "De opgegeven gebruiker kan niet worden gevonden!")
        .setFooter(config.footer, client.user.displayAvatarURL())

        var errorEmbed4 = new discord.MessageEmbed()
        .addField("**:x: Error:**", "Je kan deze gebruiker niet bannen!")
        .setColor(config.color)
        .setFooter(config.footer, client.user.displayAvatarURL())

        const geenpermissies = new discord.MessageEmbed()
        .setColor(config.color)
        .addField("**:x: Error:**", "Je hebt hier geen permissies voor!")
        .setFooter(config.footer, client.user.displayAvatarURL())
        if(!message.member.permissions.has("BAN_MEMBERS")) return message.channel.send(geenpermissies)

        const ikgeenpermissies = new discord.MessageEmbed()
        .setColor(config.color)
        .addField("**:x: Error:**", "Ik heb hier geen permissies voor!")
        .setFooter(config.footer, client.user.displayAvatarURL())
        if(!message.guild.me.permissions.has("BAN_MEMBERS")) return message.channel.send(ikgeenpermissies)

        const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

        if(!args[0]) return message.channel.send(noUserGiven);

        if (member.hasPermission("BAN_MEMBERS")) return message.channel.send(errorEmbed4);

        if(!member) return message.channel.send(noUserFound);

        var reason = args.slice(1).join(" ");

        if(!reason) reason = 'Geen reden opgegeven.';

        try{     
        member.ban({ reason: reason })
              
        const banMessage = new discord.MessageEmbed()
        .setTitle('Gebruiker gebanned!')
        .setThumbnail(member.user.displayAvatarURL())
        .addField('Gebruiker:', member)
        .addField('Moderator:', message.author)
        .addField('Reden:', reason)
        .setFooter(config.footer, client.user.displayAvatarURL())
        .setColor(config.color)

        message.channel.send(banMessage);
        } catch (e) {
                message.channel.send(':x: Er is iets misgegaan.')
                console.log(e)
        }
}

module.exports.help = {
name: "ban",
cat: "mod",
desc: "Hiermee kan je iemand bannen"
}
