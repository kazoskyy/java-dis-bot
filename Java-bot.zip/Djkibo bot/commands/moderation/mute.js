const discord = require('discord.js');
const config = require("../../botData/config.json");
const fs = require("fs")

module.exports.run = (client, message, args) => {

    const roleFile = JSON.parse(fs.readFileSync("./botData/muteRole.json"))

    const noMuteroleSet = new discord.MessageEmbed()
    .setColor(config.color)
    .addField("**:x: Error:**", `Stel een mute-role in met: \`${config.prefix}muterol <rol>\``)
    .setFooter(config.footer, client.user.displayAvatarURL())

    if(!roleFile[message.guild.id]) return message.channel.send(noMuteroleSet);

        const noUserGiven = new discord.MessageEmbed()
        .setColor(config.color)
        .addField("**:x: Error:**", `Gebruik het zo: \`mute <gebruiker> [reden]\``)
        .setFooter(config.footer, client.user.displayAvatarURL())

        const noUserFound = new discord.MessageEmbed()
        .setColor(config.color)
        .addField("**:x: Error:**", "De opgegeven gebruiker kan niet worden gevonden!")
        .setFooter(config.footer, client.user.displayAvatarURL())

        const geenpermissies = new discord.MessageEmbed()
        .setColor(config.color)
        .addField("**:x: Error:**", "Je hebt hier geen permissies voor!")
        .setFooter(config.footer, client.user.displayAvatarURL())
        if(!message.member.permissions.has("KICK_MEMBERS")) return message.channel.send(geenpermissies)

        const ikgeenpermissies = new discord.MessageEmbed()
        .setColor(config.color)
        .addField("**:x: Error:**", "Ik heb hier geen permissies voor!")
        .setFooter(config.footer, client.user.displayAvatarURL())
        if(!message.guild.me.permissions.has("MANAGE_MEMBERS")) return message.channel.send(ikgeenpermissies)

        const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

        if(!args[0]) return message.channel.send(noUserGiven);

        if(!member) return message.channel.send(noUserFound);

        let reason = args.slice(1).join(" ");

        if(!reason) reason = 'Geen reden opgegeven.';

        member.roles.add(roleFile[message.guild.id]).catch(err => { 
          message.channel.send(':x: Er is iets misgegaan.')
            console.log(err)
        })

        const muteMessage = new discord.MessageEmbed()
        .setTitle('Gebruiker gemute!')
        .setThumbnail(member.user.displayAvatarURL())
        .addField('Gebruiker:', member)
        .addField('Moderator:', message.author)
        .addField('Reden:', reason)
        .setFooter(config.footer, client.user.displayAvatarURL())
        .setColor(config.color)

        message.channel.send(muteMessage);
}

module.exports.help = {

name: "mute",
cat: "mod",
desc: "Hiermee kan je iemand muten"

}