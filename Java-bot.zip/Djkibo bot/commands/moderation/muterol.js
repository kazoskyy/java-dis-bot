const discord = require('discord.js');
const fs = require("fs")
let config = require("../../botData/config.json");
let roleFile = JSON.parse(fs.readFileSync("./botData/muteRole.json"))

module.exports.run = (client, message, args) => {

        const noRoleGiven = new discord.MessageEmbed()
        .setColor(config.color)
        .addField("**:x: Error:**", `Gebruik het zo: \`${config.prefix}muterol <rol>\``)
        .setFooter(config.footer, client.user.displayAvatarURL())

        const noRoleFound = new discord.MessageEmbed()
        .setColor(config.color)
        .addField("**:x: Error:**", "De opgegeven role kan niet worden gevonden!")
        .setFooter(config.footer, client.user.displayAvatarURL())

        const ikgeenpermissies = new discord.MessageEmbed()
        .setColor(config.color)
        .addField("**:x: Error:**", "Ik heb hier geen permissies voor!")
        .setFooter(config.footer, client.user.displayAvatarURL())
        if(!message.guild.me.permissions.has("MANAGE_ROLES")) return message.channel.send(ikgeenpermissies)

        const geenpermissies = new discord.MessageEmbed()
        .setColor(config.color)
        .addField("**:x: Error:**", "Je hebt hier geen permissies voor!")
        .setFooter(config.footer, client.user.displayAvatarURL())
        if(!message.member.permissions.has("ADMINISTRATOR")) return message.channel.send(geenpermissies)

        const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]);

        if(!args[0]) return message.channel.send(noRoleGiven);

        if(!role) return message.channel.send(noRoleFound);

        const rolesetMessage = new discord.MessageEmbed()
        .addField(`**✅ Succes:**`, `De mute rol is gezet!\n[${role}]`)
        .setColor(config.color)
        .setFooter(config.footer, client.user.displayAvatarURL())
        message.channel.send(rolesetMessage);

        roleFile[message.guild.id] = role.id
            save()     

        function save(){
            fs.writeFileSync("./botData/muteRole.json", JSON.stringify(roleFile));
        }
}

module.exports.help = {

name: "muterol",
cat: "mod",
desc: "Hiermee kan je de mute-rol instellen"

}