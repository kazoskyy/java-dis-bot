const discord = require('discord.js');
const fs = require("fs")
const config = require("../../botData/config.json");

module.exports.run = async(client, message, args) => {
    let time = 5e3;

    var categoryId = config.ticketcat
    const roleFile = JSON.parse(fs.readFileSync("./botData/supportRole.json"))    

    const errorembed = new discord.MessageEmbed()
    .setColor(config.color)
    .addField("**:x: Error:**", "Je hebt hier geen permissies voor!")
    .setFooter(config.footer, client.user.displayAvatarURL())
    if (!message.member.roles.cache.find(r => r.id === roleFile[message.guild.id])) return message.channel.send(errorembed)

    var errorEmbed2 = new discord.MessageEmbed()
    .setColor(config.color)
    .addField("**:x: Error:**", "Dit is geen ticket kanaal!")
    .setFooter(config.footer, client.user.displayAvatarURL())
    if(!message.channel.name.startsWith(config.ticketnaam)) {const fail =  await message.channel.send(errorEmbed2);setTimeout(() => {fail.delete()}, 6000);return}

    var embed = new discord.MessageEmbed()
    .addField(`**✅ Succes:**`, `Ik verwijder dit ticket in **${time/1e3}** seconden. Stuur **annuleer** om het stop te zetten.`)
    .setColor(config.color)
    .setFooter(config.footer, client.user.displayAvatarURL())
        
    let msg =  await message.channel.send(embed);
    let collector = msg.channel.createMessageCollector(m => m.content.toLowerCase().includes("annuleer"), { time: time, max: 1 })
    collector.on("end", collected => {
    
        if(collected.size < 1){
            msg.channel.delete();
        }
        var embed2 = new discord.MessageEmbed()
        .addField(`**✅ Succes:**`, `Je hebt het ticket gered!`)
        .setColor(config.color)
        .setFooter(config.footer, client.user.displayAvatarURL())
        msg.channel.send(embed2);
    })
}
module.exports.help = {

name: "close",
cat: "ticket",
desc: "Sluit een ticket"

}