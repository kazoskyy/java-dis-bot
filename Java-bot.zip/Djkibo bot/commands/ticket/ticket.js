const discord = require('discord.js');
const fs = require("fs")
const config = require("../../botData/config.json");

module.exports.run = async (client, message, args) => {
    
            var userName = message.member.displayName;
            
            var topic = args.join(" ")
            if(topic == ""){
                topic = "niet opgegeven"
            }
            
            var cat = config.ticketcat;

            const roleFile = JSON.parse(fs.readFileSync("./botData/supportRole.json"))    
                        await message.guild.channels.create("🎫 Ticket" + "-" + message.member.displayName, {
                            type: 'text',
                            parent: cat
                        }).then(async settedParent => {   
                            await settedParent.lockPermissions()

                            settedParent.updateOverwrite(message.guild.roles.cache.find(x => x.name === '@everyone'), {
                                SEND_MESSAGES: false,
                                VIEW_CHANNEL: false,
                            });
                            
                            await settedParent.updateOverwrite(message.author, {
                                VIEW_CHANNEL: true,
                                SEND_MESSAGES: true,
                                READ_MESSAGES_HISTORY: true,
                                ATTACH_FILES: true
                            })
                            await settedParent.updateOverwrite(roleFile[message.guild.id], {
                                VIEW_CHANNEL: true,
                                SEND_MESSAGES: true,
                                READ_MESSAGES_HISTORY: true,
                                ATTACH_FILES: true
                            })
                    //settedParent.setTopic(topic)

                        var embedParent = new discord.MessageEmbed()
                            .setTitle("Hallo, " + userName.toString())
                            .setDescription(`Stel alvast uw vraag, zodat wij u zo snel mogelijk kunnen helpen!\n\n**Onderwerp:** ${topic}`)
                            .setColor(config.color)
                            .setFooter(config.footer)
                        
                        var succesembed = new discord.MessageEmbed()
                            .addField(`**✅ Succes:**`, `Uw ticket is aangemaakt!\n[${settedParent}]`)
                            .setColor(config.color)
                            .setFooter(config.footer, client.user.displayAvatarURL())
                        message.channel.send(succesembed)
                        
                        settedParent.send(`${message.member}`, embedParent);
              
                        }).catch(err => {
                            console.log(err)
                        });
}

module.exports.help = {

name: "ticket",
cat: "ticket",
desc: "Open een nieuwe ticket"

}