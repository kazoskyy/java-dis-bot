const discord = require("discord.js");
const ms = require('ms');
const config = require("../../botData/config.json");
 
module.exports.run = async (client, message, args) => {

    const geenpermissies = new discord.MessageEmbed()
    .setColor(config.color)
    .addField("**:x: Error:**", `Je hebt hier geen permissies voor!`)
    .setFooter(config.footer, client.user.displayAvatarURL())
    if(!message.member.permissions.has("BAN_MEMBERS")) return message.channel.send(geenpermissies)

    const ikgeenpermissies = new discord.MessageEmbed()
    .setColor(config.color)
    .addField("**:x: Error:**", "Ik heb hier geen permissies voor!")
    .setFooter(config.footer, client.user.displayAvatarURL())
    if(!message.guild.me.permissions.has("ADMINISTRATOR")) return message.channel.send(ikgeenpermissies)
    

let giveaway = client.giveawaysManager.giveaways.find((g) => g.prize === args.join(" ")) || client.giveawaysManager.giveaways.find((g) => g.messageID === args[0]);

const fout3embed = new discord.MessageEmbed()
.setColor(config.color)
.addField("**:x: Error:**", `Je moet een giveaway ID opgeven!\nGebruik het command zo: \`${config.prefix}reroll <bericht ID van giveaway>\``)
.setFooter(config.footer, client.user.displayAvatarURL())
if(!giveaway) return message.reply(fout3embed);

message.delete()
message.channel.send(`✅ De giveaway is gererolled!`);

client.giveawaysManager.reroll(giveaway.messageID, {
    messages: {
        congrat: ":tada: Nieuwe winnaar(s) : {winners}! Gefeliciteerd!",
        error: ":x: Er zijn niet genoeg deelnemers aan deze giveaway!"
    }


}).catch((e) => {
    const fout4embed = new discord.MessageEmbed()
    .setColor(config.color)
    .addField("**:x: Error:**", `De giveaway met het ID ${giveaway.messageID}, is nog niet beëindigt.`)
    .setFooter(config.footer, client.user.displayAvatarURL())
    message.channel.send(fout4embed);

    if(e.startsWith(fout4embed)){
    } else {
        console.error(e);
    }
    });
}


module.exports.help = {
    name: "reroll",
    cat: "andere",
    desc: "Reroll een giveaway"
}