const discord = require("discord.js");
const ms = require('ms');
const config = require("../../botData/config.json");
 
module.exports.run = async(client, message, args) => {

    const geenpermissies = new discord.MessageEmbed()
    .setColor(config.color)
    .addField("**:x: Error:**", `Je hebt hier geen permissies voor!`)
    .setFooter(config.footer, client.user.displayAvatarURL())
    if(!message.member.permissions.has("BAN_MEMBERS")) return message.channel.send(geenpermissies)

    const ikgeenpermissies = new discord.MessageEmbed()
    .setColor(config.color)
    .addField("**:x: Error:**", "Ik heb hier geen permissies voor!")
    .setFooter(config.footer, client.user.displayAvatarURL())
    if(!message.guild.me.permissions.has("ADMINISTRATOR")) return message.channel.send(ikgeenpermissies)
    
    let channel = message.mentions.channels.first();
            
    const fout3embed = new discord.MessageEmbed()
    .setColor(config.color)
    .addField("**:x: Error:**", `Geef een geldig kanaal op!\nGebruik het command zo: \`${config.prefix}giveaway <kanaal> <tijd> <aantal winaars> <prijs>\``)
    .setFooter(config.footer, client.user.displayAvatarURL())
    if (!channel) return message.channel.send(fout3embed);
    
    let giveawayDuration = args[1];
    
    const fout4embed = new discord.MessageEmbed()
    .setColor(config.color)
    .addField("**:x: Error:**", `Je moet een geldige tijd opgeven!\nGebruik het command zo: \`${config.prefix}giveaway <kanaal> <tijd> <aantal winaars> <prijs>\``)
    .setFooter(config.footer, client.user.displayAvatarURL())
    if (!giveawayDuration || isNaN(ms(giveawayDuration))) return message.channel.send(fout4embed);
    
    let giveawayWinners = args[2];
    
    const fout5embed = new discord.MessageEmbed()
    .setColor(config.color)
    .addField("**:x: Error:**", `Je moet een geldig aantal winnaar(s) opgeven!\nGebruik het command zo: \`${config.prefix}giveaway <kanaal> <tijd> <aantal winaars> <prijs>\``)
    .setFooter(config.footer, client.user.displayAvatarURL())
    if (isNaN(giveawayWinners) || (parseInt(giveawayWinners) <= 0)) return message.channel.send(fout5embed);
    
    let giveawayPrize = args.slice(3).join(" ");
    
    const fout6embed = new discord.MessageEmbed()
    .setColor(config.color)
    .addField("**:x: Error:**", `Je moet een prijs opgeven!\nGebruik het command zo: \`${config.prefix}giveaway <kanaal> <tijd> <aantal winaars> <prijs>\``)
    .setFooter(config.footer, client.user.displayAvatarURL())
    if (!giveawayPrize) return message.channel.send(fout6embed);

            message.delete();
    
            client.giveawaysManager.start(channel, {
                time: ms(giveawayDuration),
                prize: giveawayPrize,
                winnerCount: giveawayWinners,
    
                messages: {
                    giveaway: ("🎉**GIVEAWAY TIME** 🎉"),
                    giveawayEnded: ("🎉**GIVEAWAY GEËINDIGT** 🎉"),
                    timeRemaining: "Tijd over: **{duration}**",
                    inviteToParticipate: "Reageer met 🎉 om mee te doen",
                    winMessage: "GG {winners}, je hebt **{prize}** gewonnen! 🎉🎉🎉",
                    embedFooter: config.footer,
                    noWinner: "Er is geen winnaar!",
                    winners: "winnaar(s)",
                    endedAt: "Giveaway geëindigt",
                    units: {
                        seconds: "seconden",
                        minutes: "minuten",
                        hours: "uren",
                        days: "dagen",
                        pluralS: false
                    }
                }
            })

        var succesembed = new discord.MessageEmbed()
        .addField(`**✅ Succes:**`, `De giveaway is gestart in ${channel}!`)
        .setColor(config.color)
        .setFooter(config.footer, client.user.displayAvatarURL())
        message.channel.send(succesembed)
        
        }
 
 
module.exports.help = {
    name: "giveaway",
    cat: "andere",
    desc: "Start een giveaway"
}